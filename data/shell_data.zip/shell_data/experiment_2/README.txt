Experiment 2
============
Testing for differences in gene expression in clinical
patient samples of ocular vitreous; specifically considering
proliferative diabetic retinopathy (PDR) vs macular hole (MH).
Samples were sequenced March 2021 and raw FASTQ files
were downloaded from the sequencing center on 4/1.

4/15/2021
cgates@umich.edu

Files
-----
fastq/: untrimmed FASTQs from sequencing center
sample_data.txt: tab-separated text file of key clinical data.
sample_data.glossary.txt: basic annotation for data above.

---
